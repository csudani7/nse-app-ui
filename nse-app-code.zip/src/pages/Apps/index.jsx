import React from "react";

export default function Apps() {
  return (
    <div
      style={{
        paddingLeft: "45px",
        backgroundColor: "#fff",
        fontSize: "24px",
        paddingTop: "30px",
      }}
    >
      Apps Page
    </div>
  );
}
